class Ex07{
	public static void main(String args[])
	{
		//Find ASCII Value of a Character
		char a = '&';
		System.out.println("The Character is: "+a);
		
		
		// Change that character in to integer
		int CharValue = (int)a;
		System.out.println("ASCII value is: "+CharValue);
		
		// Change double value into a integer
		double b = 152.63;
		System.out.println("The Double value is: "+b);
		
		// Change that double value in to integer
		int ChangedVal = (int)b;
		System.out.println("Interger Value is: "+ChangedVal);
		
	}
}
