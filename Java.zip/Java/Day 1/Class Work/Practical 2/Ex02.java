class Ex02{
	public static void main(String args[])
	{
		String name = "Vishwa";
		int age = 20;
		double PI = 3.1415;
		int m = 4;
		char SD = '*';
		boolean isTH = true;
		
		System.out.println(name);
		System.out.println(age);
		System.out.println(PI);
		System.out.println(m);
		System.out.println(SD);
		System.out.println(isTH);
		
		System.out.println("My name is "+name);
		System.out.println("My age is "+ (age+m));
		System.out.println("The result is "+(PI+m));
		
	}
}