class Myjava{
	public static void main (String[] args)
		{ 
		    System.out.println("My First Programm Java");
			System.out.println("Hello Java Developer");
		}
	}
			
		