class Ex05{
public static void main(String args[])
	{
		System.out.println("Name: Vishwa Sudaraka");
		System.out.println("Registration Number: 2022/ASP/12");
		System.out.println("Degree Program: Undergraduate");
		
		String Name = "Vishwa Sudaraka";
		String RNo = "2022/ASP/12";
		String DPro = "Undergraduate";
		
		System.out.println("Name: "+Name);
		System.out.println("Registration Number: "+RNo);
		System.out.println("Degree Program: "+DPro);
	}
}