class Ex06{
	public static void main(String args[])
	{
		System.out.println("Name: Vishwa Sudaraka \nRegistration Number: 2022/ASP/12  \nDegree Program: Undergraduate");
	}
}
		