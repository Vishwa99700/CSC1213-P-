public class Ex03{
	public static void main(String args[])
	{
		int num1 = 20;
		int num2 = 5;
		
		int add = num1+num2;
		int sub = num1-num2;
		int mul = num1*num2;
		int div = num1/num2;
		int mod = num1%num2;
		
		System.out.println("Addition :"+add);
		System.out.println("Substraction :"+sub);
		System.out.println("Multiplication :"+mul);
		System.out.println("Divition :"+div);
		System.out.println("Module :"+mod);
	}
}